from torch.nn.functional import one_hot
import torch
import torch.nn as nn
import numpy as np
import pickle
import os
from torch.utils.data import DataLoader, TensorDataset
from pathlib import Path
import ml_collections
import yaml

def load_config(algo):
    try:
        with open("config.yaml") as file:
            config = ml_collections.ConfigDict(yaml.safe_load(file))

        with open("model_config.yaml") as file:
            model_config = ml_collections.ConfigDict(yaml.safe_load(file))
    except:
        # Start search from the script's directory
        start_path = Path(__file__).resolve().parent
        data_folder = find_data_folder(start_path)

        if data_folder:
            config_dir = data_folder / "tsg_library/models/config.yaml"

        with open(config_dir) as file:
            config = ml_collections.ConfigDict(yaml.safe_load(file))

        config, model_config = process_config(config, algo)

        with open("model_config.yaml", "w") as file:
            yaml.dump(model_config, file, default_flow_style=False)

        with open("config.yaml", "w") as file:
            yaml.dump(config, file, default_flow_style=False)

    return config, model_config

def process_config(config, algo):
    config.algo = algo

    # Flat the config file by reading the model config
    if 'Model' in config.keys():
        model_config = {}
        for k, v in config.Model[config.algo].items():
            model_config[k] = v

        del config.Model

    if (config.device ==
            "cuda" and torch.cuda.is_available()):
        config.update({"device": "cuda:0"}, allow_val_change=True)
    else:
        config.update({"device": "cpu"}, allow_val_change=True)

    # config.update({"n_lags": data.shape[1]}, allow_val_change=True)
    #
    # config.update({"input_dim": data.shape[-1]}, allow_val_change=True)

    return config, model_config


def find_data_folder(start_path: Path):
    """Search upwards for the 'data' folder."""
    current = start_path.resolve()
    while current != current.parent:  # Stop at root
        data_folder = current / "data"
        if data_folder.exists() and data_folder.is_dir():
            return data_folder
        current = current.parent
    return None  # Not found


def to_device(x):
    return x.to("cuda")

def to_numpy(x):
    """
    Casts torch.Tensor to a numpy ndarray.

    The function detaches the tensor from its gradients, then puts it onto the cpu and at last casts it to numpy.
    """
    return x.detach().cpu().numpy()


def count_parameters(model: torch.nn.Module) -> int:
    """

    Args:
        model (torch.nn.Module): input models
    Returns:
        int: number of trainable parameters in the model
    """
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


def get_time_vector(size: int, length: int) -> torch.Tensor:
    return torch.linspace(1/length, 1, length).reshape(1, -1, 1).repeat(size, 1, 1)


"""
class BaseAugmentation:
    pass

    def apply(self, *args: List[torch.Tensor]) -> torch.Tensor:
        raise NotImplementedError('Needs to be implemented by child.')


@dataclass
class AddTime(BaseAugmentation):

    def apply(self, x: torch.Tensor):
        t = get_time_vector(x.shape[0], x.shape[1]).to(x.device)
        return torch.cat([t, x], dim=-1)
"""


def AddTime(x):
    t = get_time_vector(x.shape[0], x.shape[1]).to(x.device)
    return torch.cat([t, x], dim=-1)


def sample_indices(dataset_size, batch_size):
    indices = torch.from_numpy(np.random.choice(
        dataset_size, size=batch_size, replace=False)).cuda()
    # functions torch.-multinomial and torch.-choice are extremely slow -> back to numpy
    return indices.long()


def to_numpy(x):
    """
    Casts torch.Tensor to a numpy ndarray.

    The function detaches the tensor from its gradients, then puts it onto the cpu and at last casts it to numpy.
    """
    return x.detach().cpu().numpy()


def set_seed(seed: int):
    """ Sets the seed to a specified value. Needed for reproducibility of experiments. """
    torch.manual_seed(seed)
    np.random.seed(seed)


def save_obj(obj: object, filepath: str):
    """ Generic function to save an object with different methods. """
    if filepath.endswith('pkl'):
        saver = pickle.dump
    elif filepath.endswith('pt'):
        saver = torch.save
    else:
        raise NotImplementedError()
    with open(filepath, 'wb') as f:
        saver(obj, f)
    return 0


def load_obj(filepath):
    """ Generic function to load an object. """
    if filepath.endswith('pkl'):
        loader = pickle.load
    elif filepath.endswith('pt'):
        loader = torch.load
    elif filepath.endswith('json'):
        import json
        loader = json.load
    else:
        raise NotImplementedError()
    with open(filepath, 'rb') as f:
        return loader(f)


def init_weights(m):
    if isinstance(m, nn.Linear):
        nn.init.xavier_uniform_(
            m.weight.data, gain=nn.init.calculate_gain('relu'))
        try:
            # m.bias.zero_()#, gain=nn.init.calculate_gain('relu'))
            nn.init.zeros_(m.bias)
        except:
            pass


def get_experiment_dir(config):
    if config.model_type == 'VAE':
        exp_dir = './numerical_results/{dataset}/algo_{gan}_Model_{model}_n_lag_{n_lags}_{seed}'.format(
            dataset=config.dataset, gan=config.algo, model=config.model, n_lags=config.n_lags, seed=config.seed)
    else:
        exp_dir = './numerical_results/{dataset}/algo_{gan}_G_{generator}_D_{discriminator}_includeD_{include_D}_n_lag_{n_lags}_{seed}'.format(
            dataset=config.dataset, gan=config.algo, generator=config.generator,
            discriminator=config.discriminator, include_D=config.include_D, n_lags=config.n_lags, seed=config.seed)
    os.makedirs(exp_dir, exist_ok=True)
    if config.train and os.path.exists(exp_dir):
        print("WARNING! The model exists in directory and will be overwritten")
    config.exp_dir = exp_dir


def loader_to_tensor(dl):
    tensor = []
    for x in dl:
        tensor.append(x[0])
    return torch.cat(tensor)


def loader_to_cond_tensor(dl, config):
    tensor = []
    for _, y in dl:
        tensor.append(y)

    return one_hot(torch.cat(tensor), config.num_classes).unsqueeze(1).repeat(1, config.n_lags, 1)

def combine_dls(dls):
    return torch.cat([loader_to_tensor(dl) for dl in dls])


def fake_loader(generator, x_past, n_lags, batch_size, **kwargs):
    """
    Helper function that transforms the generated data into dataloader, adapted from different generative models
    Parameters
    ----------
    generator: nn.module, trained generative model
    x_past: torch.tensor, real past path
    num_samples: int,  number of paths to be generated
    n_lags: int, the length of path to be generated
    batch_size: int, batch size for dataloader
    kwargs

    Returns
    Dataload of generated data
    -------

    """
    with torch.no_grad():
        fake_data_future = generator(n_lags, x_past)
        fake_data = torch.cat([x_past, fake_data_future], dim=1)
    return DataLoader(TensorDataset(fake_data), batch_size=batch_size)

def log_return_to_price(log_returns, initial_prices):
    """
    Convert log returns to price process.

    Args:
    - log_returns: Tensor of shape [N, T, d], log return process.
    - initial_prices: Tensor of shape [N, 1, d], initial prices.

    Returns:
    - prices: Tensor of shape [N, T+1, d], price process.
    """
    # Get the shapes
    N, T, d = log_returns.shape

    # Create a tensor to hold the prices, which will have one more time step than the log returns
    prices = torch.zeros((N, T + 1, d), device=log_returns.device)

    # Set the initial prices
    prices[:, 0, :] = initial_prices.squeeze(1)

    # Iteratively compute the price at each time step
    for t in range(1, T + 1):
        prices[:, t, :] = prices[:, t - 1, :] * torch.exp(log_returns[:, t - 1, :])

    return prices[:, 1:, :]