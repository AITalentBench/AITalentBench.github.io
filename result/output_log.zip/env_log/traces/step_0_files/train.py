import numpy as np
import random
import torch
import os
import pickle
from eval import evaluate, evaluation_pipeline
from utils import log_return_to_price, to_device, set_seed, find_data_folder, load_config, process_config, save_obj
from data.tsg_library.models.models import get_trainer
from torch.utils.data import DataLoader, TensorDataset
import ml_collections

SEED = 42
random.seed(SEED)
torch.manual_seed(SEED)
np.random.seed(SEED)


def get_data():
    # DO NOT MODIFY!

    lst = []
    for dtype in ["train", "val", "truth"]:
        # print(os.path.join(f"{dtype}_log_return.pkl"))
        # Load test data
        truth_file = os.path.join(f"{dtype}_log_return.pkl")
        if not os.path.isfile(truth_file):
            raise Exception('Data not supplied')
        with open(truth_file, "rb") as f:
            log_return = to_device(torch.tensor(pickle.load(f)).float())
        # print(os.path.join(f"{dtype}_price.pkl"))
        truth_file = os.path.join(f"{dtype}_price.pkl")
        if not os.path.isfile(truth_file):
            raise Exception('Data not supplied')
        with open(truth_file, "rb") as f:
            init_price = to_device(torch.tensor(pickle.load(f)).float())

        price = log_return_to_price(log_return, init_price)
        lst.append(log_return)

    return lst

def data_processing(data):
    # TODO. preprocess the data, should return the processed data
    processed_data = data
    return processed_data

def revert_processing(processed_data):
    # TODO. revert the effect of data_processing(), should return the reverted data
    raw_data = processed_data
    return raw_data


def train_model(X_train, X_valid):
    # TODO. define and train the model, should return the trained model
    model = None
    return model

def modify_config(model_config):
    # TODO. If you want to change some of the hyper-parameters, please do it here:
    value_to_changed = model_config.lr_G
    model_config.update({"lr_G": value_to_changed}, allow_val_change=True)
    return model_config

def generate(trainer, batch_size):
    y_pred = trainer.generate(batch_size)
    return y_pred

def run(algo):
    # DO NOT MODIFY!

    config, model_config = load_config(algo)

    config = ml_collections.ConfigDict(config)
    model_config = ml_collections.ConfigDict(model_config)

    X_train_raw, X_valid_raw, X_test_raw = get_data()

    config.update({"n_lags": X_train_raw.shape[1]}, allow_val_change=True)

    config.update({"input_dim": X_train_raw.shape[-1]}, allow_val_change=True)

    model_config = modify_config(model_config)

    config.update(model_config)

    # Set the seed
    set_seed(config.seed)

    # Apply data processing to facilitate the training
    X_train_processed = data_processing(X_train_raw)
    X_valid_processed = data_processing(X_valid_raw)

    train_dl = DataLoader(
        TensorDataset(X_train_processed),
        batch_size=config.batch_size,
    )
    valid_dl = DataLoader(
        TensorDataset(X_valid_processed),
        batch_size=config.batch_size,
    )

    trainer = get_trainer(config, train_dl, valid_dl)

    """
    Model training
    """

    trainer.fit(config.device)
    trainer.save_loss_history()

    """
    Model Evaluation
    """
    pipeline_evaluation_summary = evaluation_pipeline(trainer, X_test_raw, config)

    print("The result from our own evaluation pepeline on the test dataset: \n", pipeline_evaluation_summary)

    # should fill out the predict function
    X_fake = generate(trainer, X_valid_raw.shape[0])

    # Revert the data processing to obtain original data
    X_fake_raw = revert_processing(X_fake)

    score_val = evaluate(X_valid_raw, X_fake_raw)
    print("final score on validation set: ", score_val)

    X_fake = generate(trainer, X_test_raw.shape[0])

    # Revert the data processing to obtain original data
    X_fake_raw = revert_processing(X_fake)

    score_test = evaluate(X_test_raw, X_fake_raw)
    print("final score on test set: ", score_test)

if __name__ == '__main__':
    algo = "RCGAN" # Choose the algo name based on the experiment plan
    run(algo)