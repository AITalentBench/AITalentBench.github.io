import numpy as np
import random
import torch
import os
import pickle
from eval import evaluate, evaluation_pipeline
from utils import log_return_to_price, to_device, set_seed, find_data_folder, load_config, process_config, save_obj
from data.tsg_library.models.models import get_trainer
from torch.utils.data import DataLoader, TensorDataset
import ml_collections
from sklearn.preprocessing import StandardScaler
import pandas as pd

SEED = 42
random.seed(SEED)
torch.manual_seed(SEED)
np.random.seed(SEED)


def get_data():
    # DO NOT MODIFY!

    lst = []
    for dtype in ["train", "val", "truth"]:
        # print(os.path.join(f"{dtype}_log_return.pkl"))
        # Load test data
        truth_file = os.path.join(f"{dtype}_log_return.pkl")
        if not os.path.isfile(truth_file):
            raise Exception('Data not supplied')
        with open(truth_file, "rb") as f:
            log_return = to_device(torch.tensor(pickle.load(f)).float())
        # print(os.path.join(f"{dtype}_price.pkl"))
        truth_file = os.path.join(f"{dtype}_price.pkl")
        if not os.path.isfile(truth_file):
            raise Exception('Data not supplied')
        with open(truth_file, "rb") as f:
            init_price = to_device(torch.tensor(pickle.load(f)).float())

        price = log_return_to_price(log_return, init_price)
        lst.append(log_return)

    return lst

def data_processing(data):
    # Implementing data normalization
    scaler = StandardScaler()
    # Move data to CPU for scaling
    data_cpu = data.cpu().numpy()
    data_scaled = scaler.fit_transform(data_cpu.reshape(-1, data_cpu.shape[-1])).reshape(data_cpu.shape)
    # Convert back to tensor and move to appropriate device
    data_scaled_tensor = torch.tensor(data_scaled, dtype=torch.float32, device=data.device)
    return data_scaled_tensor, scaler

def revert_processing(processed_data, scaler):
    # Reverting the effect of data_processing()
    # Detach from the computation graph and move data to CPU for inverse scaling
    processed_data_cpu = processed_data.detach().cpu().numpy()
    raw_data = scaler.inverse_transform(processed_data_cpu.reshape(-1, processed_data_cpu.shape[-1])).reshape(processed_data_cpu.shape)
    # Convert back to tensor and move to appropriate device
    raw_data_tensor = torch.tensor(raw_data, dtype=torch.float32, device=processed_data.device)
    return raw_data_tensor

def train_model(X_train, X_valid):
    # TODO. define and train the model, should return the trained model
    model = None
    return model

def modify_config(model_config):
    # TODO. If you want to change some of the hyper-parameters, please do it here:
    value_to_changed = model_config.lr_G
    model_config.update({"lr_G": value_to_changed}, allow_val_change=True)
    return model_config

def generate(trainer, batch_size):
    y_pred = trainer.generate(batch_size)
    return y_pred

def run(algo):
    # DO NOT MODIFY!

    config, model_config = load_config(algo)

    config = ml_collections.ConfigDict(config)
    model_config = ml_collections.ConfigDict(model_config)

    X_train_raw, X_valid_raw, X_test_raw = get_data()

    config.update({"n_lags": X_train_raw.shape[1]}, allow_val_change=True)

    config.update({"input_dim": X_train_raw.shape[-1]}, allow_val_change=True)

    model_config = modify_config(model_config)

    config.update(model_config)

    # Set a default value for epochs if not present
    if 'epochs' not in config:
        config.epochs = 100  # Set to a reasonable default value

    # Set the seed
    set_seed(config.seed)

    # Apply data processing to facilitate the training
    X_train_processed, train_scaler = data_processing(X_train_raw)
    X_valid_processed, valid_scaler = data_processing(X_valid_raw)

    train_dl = DataLoader(
        TensorDataset(X_train_processed),
        batch_size=config.batch_size,
    )
    valid_dl = DataLoader(
        TensorDataset(X_valid_processed),
        batch_size=config.batch_size,
    )

    trainer = get_trainer(config, train_dl, valid_dl)

    """
    Model training
    """
    # Implement early stopping
    early_stopping_patience = 10
    best_val_loss = float('inf')
    epochs_no_improve = 0

    for epoch in range(config.epochs):
        trainer.fit(config.device)
        
        # Compute validation loss by iterating over the validation DataLoader
        val_loss = 0.0
        for batch in valid_dl:
            batch_data = batch[0]
            batch_loss = trainer.evaluate(batch_data)  # Ensure this method exists in your trainer
            if batch_loss is not None:  # Check if batch_loss is not None
                val_loss += batch_loss.item()
        val_loss /= len(valid_dl)
        
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            epochs_no_improve = 0
            # Save the model's state if the trainer has a model attribute
            if hasattr(trainer, 'model'):
                torch.save(trainer.model.state_dict(), 'best_model.pth')
        else:
            epochs_no_improve += 1
            if epochs_no_improve >= early_stopping_patience:
                print(f'Early stopping at epoch {epoch}')
                break

    # Ensure losses_history is consistent
    if hasattr(trainer, 'losses_history'):
        # Make sure all arrays in losses_history are of the same length
        min_length = min(len(v) for v in trainer.losses_history.values())
        for key in trainer.losses_history:
            trainer.losses_history[key] = trainer.losses_history[key][:min_length]

    trainer.save_loss_history()

    """
    Model Evaluation
    """
    pipeline_evaluation_summary = evaluation_pipeline(trainer, X_test_raw, config)

    print("The result from our own evaluation pipeline on the test dataset: \n", pipeline_evaluation_summary)

    # should fill out the predict function
    X_fake = generate(trainer, X_valid_raw.shape[0])

    # Revert the data processing to obtain original data
    X_fake_raw = revert_processing(X_fake, valid_scaler)

    score_val = evaluate(X_valid_raw, X_fake_raw)
    print("final score on validation set: ", score_val)

    X_fake = generate(trainer, X_test_raw.shape[0])

    # Revert the data processing to obtain original data
    X_fake_raw = revert_processing(X_fake, train_scaler)

    score_test = evaluate(X_test_raw, X_fake_raw)
    print("final score on test set: ", score_test)

if __name__ == '__main__':
    algo = "RCGAN" # Choose the algo name based on the experiment plan
    run(algo)