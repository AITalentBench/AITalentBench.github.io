import torch
from data.tsg_library.evaluations.summary import full_evaluation_latest

def tail_metric(x, alpha, statistic):
    # DO NOT MODIFY!
    res = list()
    for i in range(x.shape[2]):
        tmp_res = list()
        # Exclude the initial point
        for t in range(x.shape[1]):
            x_ti = x[:, t, i]
            sorted_arr, _ = torch.sort(x_ti)
            var_alpha_index = int(alpha * len(sorted_arr))
            var_alpha = sorted_arr[var_alpha_index]
            if statistic == "es":
                es_values = sorted_arr[:var_alpha_index + 1]
                es_alpha = es_values.mean()
                tmp_res.append(es_alpha)
            else:
                tmp_res.append(var_alpha)
        res.append(tmp_res)
    return res


def evaluate(x_real, x_fake):
    # DO NOT MODIFY!
    final_loss = 0
    for metric in ["var", "es"]:
        loss_lst = []
        var = tail_metric(x=x_real, alpha=0.95, statistic=metric)
        var_fake = tail_metric(x=x_fake, alpha=0.95, statistic=metric)
        for i in range(x_fake.shape[2]):
            for t in range(x_fake.shape[1]):
                abs_metric = torch.abs(var_fake[i][t] - var[i][t].to(x_fake.device))
                loss_lst.append(abs_metric)
        average_loss = torch.stack(loss_lst).mean().item()
        final_loss += average_loss
    return final_loss


def evaluation_pipeline(trainer, test_data, config):
    generator = trainer.G
    generator.eval()
    kwargs = {}
    if hasattr(trainer, "recovery"):
        kwargs["recovery"] = trainer.recovery

    return full_evaluation_latest(generator, test_data, config, **kwargs)